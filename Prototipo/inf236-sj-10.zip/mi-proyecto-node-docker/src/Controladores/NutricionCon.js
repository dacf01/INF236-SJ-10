const pool = require('../db');

//HU1
const Crear_Perfil = async (req,res) => {
    const {Nombre, Intolerancias} = req.body;
    await pool.query('INSERT INTO Perfiles (Nombre, Intolerancias) VALUES ($1,$2)', [Nombre,Intolerancias]);
    res.json({status:"Perfil Guardado"});
};

//HU2
const Obtener_Calorias_Hoy = async(req,res) => {
    const result = await pool.query('SELECT SUM(Calorias) as total FROM Consumos_diarios WHERE fecha = CURRENT_DATE');
    res.json({ total: result.rows[0].total || 0})
};

//HU3 
const Validar_Receta = async(req,res) => {
    const {id} = req.params;
    const {estado} = req.body;
    await pool.query('UPDATE Recetas SET Validacion = $1 WHERE id = $2', [estado,id]);
    res.json({status: "Receta Actualizada"})
};

module.exports = {Crear_Perfil, Obtener_Calorias_Hoy, Validar_Receta};