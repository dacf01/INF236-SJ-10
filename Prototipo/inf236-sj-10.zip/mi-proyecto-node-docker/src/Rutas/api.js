const express = require('express');
const router = express.Router();
const Controlador = require('../Controladores/NutricionCon');

router.post('/Perfil', Controlador.Crear_Perfil);
router.get('/Consumo/Hoy', Controlador.Obtener_Calorias_Hoy);
router.patch('/Recetas/:id/Validacion', Controlador.Validar_Receta);

module.exports = router;